package com.example.g3moodtracker

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login) // your login XML

        val btnLogin = findViewById<Button>(R.id.btnContinue)
        val txtSignup = findViewById<TextView>(R.id.txtSignup)

        // Go to Register page
        txtSignup.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        // (Optional) After successful login → Home
        btnLogin.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
    }
}
