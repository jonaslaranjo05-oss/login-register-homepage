package com.example.g3moodtracker   // ⚠️ change to your actual package name

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home) // your home XML

        // Bottom navigation buttons
        val btnHome = findViewById<MaterialButton>(R.id.btnHome)
        val btnMood = findViewById<MaterialButton>(R.id.btnMood)
        val btnJournal = findViewById<MaterialButton>(R.id.btnJournal)
        val btnProfile = findViewById<MaterialButton>(R.id.btnProfile)

        // HOME
        btnHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
        }

        // MOOD
        btnMood.setOnClickListener {
            Toast.makeText(this, "Mood Tracker", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, MoodActivity::class.java))
        }

        // JOURNAL
        btnJournal.setOnClickListener {
            Toast.makeText(this, "Journal", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, JournalActivity::class.java))
        }

        // PROFILE
        btnProfile.setOnClickListener {
            Toast.makeText(this, "Profile", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}
